# Prueba técnica – Buscador de libros y autores
[![Developer](https://img.shields.io/badge/developer-xarop.com-blue?logo=)](https://xarop.com)


Resolución del ejercicio planteado en `enunciado.docx` sobre los datos de `dataset.json`.

Contenido:

1. [Resolución estricta del enunciado](#1-resolución-estricta-del-enunciado)
2. [Referencia de la API](#2-referencia-de-la-api)
3. [Frontend de prueba (con y sin JS)](#3-frontend-de-prueba)
4. [Uso de la API desde distintos entornos](#4-uso-de-la-api-desde-distintos-entornos)
5. [Tests](#5-tests)

## Estructura

| Fichero | Descripción |
|---|---|
| `api.php` | **Entregable del enunciado**: webservice PHP |
| `dataset.json` | Datos (debe estar junto a `api.php`) |
| `index.html` | Frontend con JavaScript |
| `index.php` | Frontend sin JavaScript |
| `tests/test.php` | Tests |
| `enunciado.docx` | Enunciado |

## Requisitos

El servidor necesita **PHP** (la API y `index.php` se ejecutan en el servidor).

- **Versión mínima: PHP 7.0** (usa el operador `??`). Desarrollado y probado con PHP 8.5; compatible con 7.x y 8.x.
- Extensiones: `mbstring`, `json` y `pcre` (habituales; `json` y `pcre` vienen de serie).
- Los tests (`tests/test.php`) requieren PHP 7.1+.
- `index.html` es estático y no necesita PHP, solo un navegador y acceso a la API.

## Arranque rápido

```bash
php -S localhost:8000
```

En macOS, si utilizas Local y no tienes PHP en el `PATH`, puedes usar el PHP
incluido en la aplicación. Desde el directorio del proyecto:

```bash
export PATH="/Applications/Local.app/Contents/Resources/extraResources/lightning-services/php-8.2.29+0/bin/darwin/bin:$PATH"
php -S localhost:8000
```

La versión y la ruta pueden variar según la instalación de Local. La variable
`PATH` se modifica solo para la terminal actual; también permite ejecutar los
tests indicados más abajo en esa misma terminal.

---

## 1. Resolución estricta del enunciado

Solo se necesita `api.php` + `dataset.json` en el mismo directorio.

| Requisito | Resolución |
|---|---|
| Webservice PHP que busca libros por título y autor | `api.php` |
| Respuesta JSON con libros y autores por separado (dos arrays) | `{"libros": [...], "autores": [...]}` |
| Entrada por GET: `texto` | `api.php?texto=...` |
| Ampliación: en cada autor, sus dos últimos libros por `fecha_nov` descendente | Campo `ultimos_libros` dentro de cada elemento de `autores` |
| Búsqueda por palabras exactas, sin patrones ni similitudes | Se compara palabra a palabra (ver reglas) |
| `dataset.json` en el mismo directorio que el PHP | Se lee con `__DIR__ . '/dataset.json'` |
| Entrega: un fichero PHP | `api.php` es autocontenido |

Decisiones de interpretación:

- `libros` contiene los libros cuyo **título** coincide; `autores`, los autores cuyo **nombre** coincide.
- Si el texto tiene varias palabras, todas deben aparecer en el campo (`Jorge Franco` → autor Jorge Franco).
- El dataset trae espacios sobrantes en algunos autores (`" Osho"`); se normalizan con `trim`.
- Los registros con el mismo ISBN, título y autor se consideran el mismo libro; si hay varias fechas se conserva la más reciente. Los libros diferentes que comparten ISBN se mantienen.
- Mayúsculas/minúsculas no influyen; las tildes sí (`Paraiso` ≠ `Paraíso`).

### Duplicados y calidad de los datos

El dataset contiene registros del mismo libro con distintas portadas o fechas.
Por ejemplo, *Topito terremoto* aparece dos veces con el ISBN `9788448847906`;
*Nueve días de abril* también aparece dos veces con fechas diferentes. El
`dataset.json` entregado se mantiene sin modificar. Al procesarlo en memoria,
para evitar resultados repetidos, se agrupan los registros con el mismo ISBN,
título y autor, conservando el de fecha más reciente (o el primero si las
fechas coinciden). Esto también se aplica antes de seleccionar los dos últimos
libros de cada autor.

El ISBN por sí solo no basta para deduplicar este dataset: `9788420432793`
figura en dos libros con títulos y autores diferentes. Por prudencia, ambos
se mantienen, al igual que distintas ediciones del mismo título con ISBN
diferentes. En caso de duda, conviene consultar con quien proporcionó los
datos cuál es el registro correcto y cómo deben tratarse los duplicados. No
se puede afirmar que estas inconsistencias sean deliberadas ni que la
deduplicación sea un requisito explícito; es una decisión de interpretación.

### Fuente de datos

Tal como pide el enunciado, los datos se leen de `dataset.json` (fichero estático). La lógica de búsqueda no depende de dónde vengan: el servicio solo necesita un array de libros con los campos `titulo`, `autor`, `isbn`, `fecha_nov` y `portada`. Por tanto, la misma API podría alimentarse de:

- **Base de datos**: sustituir la lectura del JSON por una consulta (PDO) y delegar la búsqueda y la ordenación en SQL, por ejemplo:

  ```sql
  SELECT * FROM libros WHERE titulo LIKE :palabra;                    -- libros
  SELECT * FROM libros WHERE autor = :autor ORDER BY fecha_nov DESC LIMIT 2;  -- últimos libros
  ```

- **Otra API**: obtener los libros con `file_get_contents` o cURL y aplicar el mismo filtrado.

Con un dataset grande, la base de datos es preferible, porque evita cargar y recorrer todo el fichero en cada petición. El formato de la respuesta JSON no cambiaría.

---

## 2. Referencia de la API

`GET /api.php?texto=<texto>`

| Parámetro | Descripción |
|---|---|
| `texto` | Texto a buscar. Vacío o ausente → ambos arrays vacíos |

Respuesta `200 application/json`:

```json
{
  "libros": [
    {
      "titulo": "Humo",
      "autor": "Gabriela Alemán",
      "isbn": "9789588979403",
      "fecha_nov": "20170203",
      "portada": "http://static.megustaleer.com/images/libros_244_x/9789588979403.jpg"
    }
  ],
  "autores": [
    {
      "autor": "Jorge Franco",
      "ultimos_libros": [
        { "titulo": "Mala noche", "autor": "Jorge Franco", "isbn": "9789585428409", "fecha_nov": "20171006", "portada": "..." },
        { "titulo": "Santa suerte", "autor": "Jorge Franco", "isbn": "9789585428140", "fecha_nov": "20170526", "portada": "..." }
      ]
    }
  ]
}
```

Errores:

| Código | Causa | Cuerpo |
|---|---|---|
| 405 | Método distinto de GET | `{"error": "Método no permitido"}` |
| 500 | No se pudo leer `dataset.json` | `{"error": "No se pudo leer dataset.json"}` |

Incluye `Access-Control-Allow-Origin: *`, por lo que puede llamarse desde otro origen.

```bash
curl "http://localhost:8000/api.php?texto=Jorge+Franco"
```

---

## 3. Frontend de prueba

Extras, no requeridos por el enunciado.

- **Con JavaScript** – `index.html` (<http://localhost:8000/index.html>): formulario que llama a la API con `fetch` y pinta libros, autores y el JSON en bruto. Es estático: puede abrirse desde cualquier servidor web.
- **Sin JavaScript** – `index.php` (<http://localhost:8000/>): formulario GET; el HTML se genera en servidor reutilizando `api.php`. Necesita PHP.

---

## 4. Uso de la API desde distintos entornos

En los ejemplos, `BASE` es la URL donde se sirve `api.php` (p. ej. `http://localhost:8000/api.php`).

### PHP (sin framework)

```php
$url = 'http://localhost:8000/api.php?' . http_build_query(['texto' => 'Jorge Franco']);
$respuesta = json_decode(file_get_contents($url), true);

foreach ($respuesta['autores'] as $autor) {
    echo $autor['autor'] . ': ' . count($autor['ultimos_libros']) . " libros\n";
}
```

Con cURL:

```php
$ch = curl_init('http://localhost:8000/api.php?texto=' . urlencode('Humo'));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$respuesta = json_decode(curl_exec($ch), true);
curl_close($ch);
```

### Laravel

Cliente HTTP (`app/Http/Controllers/LibrosController.php`):

```php
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class LibrosController extends Controller
{
    public function buscar(Request $request)
    {
        $data = Http::get(config('services.libros.url'), ['texto' => $request->query('texto', '')])
            ->throw()
            ->json();

        return view('libros', $data); // variables $libros y $autores
    }
}
```

`config/services.php`:

```php
'libros' => ['url' => env('LIBROS_API_URL', 'http://localhost:8000/api.php')],
```

`routes/web.php`:

```php
Route::get('/libros', [App\Http\Controllers\LibrosController::class, 'buscar']);
```

Vista `resources/views/libros.blade.php`:

```blade
<form method="get"><input name="texto" value="{{ request('texto') }}"><button>Buscar</button></form>

@foreach ($libros as $l)
  <p>{{ $l['titulo'] }} – {{ $l['autor'] }}</p>
@endforeach

@foreach ($autores as $a)
  <h3>{{ $a['autor'] }}</h3>
  @foreach ($a['ultimos_libros'] as $l)
    <p>{{ $l['titulo'] }} ({{ $l['fecha_nov'] }})</p>
  @endforeach
@endforeach
```

Alternativa: copiar `api.php` y `dataset.json` a `public/` y llamarlo en `/api.php`.

### React

```jsx
import { useState } from 'react';

const API = 'http://localhost:8000/api.php';

export default function Buscador() {
  const [texto, setTexto] = useState('');
  const [datos, setDatos] = useState(null);

  async function buscar(e) {
    e.preventDefault();
    const r = await fetch(`${API}?texto=${encodeURIComponent(texto)}`);
    setDatos(await r.json());
  }

  return (
    <>
      <form onSubmit={buscar}>
        <input value={texto} onChange={e => setTexto(e.target.value)} />
        <button>Buscar</button>
      </form>
      {datos && (
        <>
          <h2>Libros</h2>
          {datos.libros.map(l => <p key={l.isbn}>{l.titulo} – {l.autor}</p>)}
          <h2>Autores</h2>
          {datos.autores.map(a => (
            <div key={a.autor}>
              <h3>{a.autor}</h3>
              {a.ultimos_libros.map(l => <p key={l.isbn}>{l.titulo} ({l.fecha_nov})</p>)}
            </div>
          ))}
        </>
      )}
    </>
  );
}
```

La API envía CORS abierto, así que funciona desde `localhost:3000`/`5173`. En desarrollo también puede usarse un proxy (`vite.config.js` → `server.proxy`).

### HTML + JavaScript

```html
<input id="texto"><button id="ok">Buscar</button>
<pre id="salida"></pre>
<script>
  document.getElementById('ok').onclick = async () => {
    const t = document.getElementById('texto').value;
    const r = await fetch('api.php?texto=' + encodeURIComponent(t));
    document.getElementById('salida').textContent = JSON.stringify(await r.json(), null, 2);
  };
</script>
```

Versión completa en `index.html`.

### HTML sin JavaScript

Basta un formulario GET apuntando a una página PHP que consuma la API (ver `index.php`). Si solo se quiere ver el JSON, el formulario puede apuntar directamente a `api.php`:

```html
<form method="get" action="api.php">
  <input name="texto" required>
  <button>Buscar</button>
</form>
```

### Otros

```bash
# curl
curl -G "http://localhost:8000/api.php" --data-urlencode "texto=Jorge Franco"
```

```python
# Python
import requests
print(requests.get("http://localhost:8000/api.php", params={"texto": "Humo"}).json())
```

---

## 5. Tests

```bash
php tests/test.php
```

Comprueban estructura de la respuesta, palabra exacta frente a subcadena, mayúsculas, eliminación de duplicados, dos últimos libros ordenados por `fecha_nov`, normalización de espacios en autores, casos sin resultados y rechazo de métodos distintos de GET.

---

## Uso de IA

He utilizado una herramienta de IA como asistente para ganar productividad, principalmente en la documentación (este README), los tests y los frontends de prueba. El planteamiento, las decisiones de diseño y la supervisión y validación del resultado son míos.

Developed by [xarop.com](https://xarop.com).
